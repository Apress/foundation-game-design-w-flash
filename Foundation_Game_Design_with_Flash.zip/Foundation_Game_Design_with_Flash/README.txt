Most of the book’s chapters make reference to these source files, which contain working examples of games, completed projects, and additional sample programs and utilities.
To make use of these source files, you need to “create a project” using Flash’s CS4’s new Project panel. Here are the steps you need to follow:
1. In Flash, make sure that the Project panel is open. If it isn't, select Window ➤ Other Panels ➤ Project.
2. In the Project panel, select Open Project from the drop-down menu.
3. Find the folder that contains the source files and select it. The source files are organizedby chapter, and the folder you’re looking for will usually be a subfolder of the chapterfolder.
4. Click the Choose button.
5. All the files required for the project will be loaded into the Project panel.

6. You now need to assign an FLA file as the default document. The default document isthe file that Flash uses to create the SWF file, which is the file that actually runs yourprogram or game. If the project's default document has already been assigned, it willbe indicated by a yellow star on the FLA file's icon. If the default document hasn’t beenassigned, you need to assign it manually. To do this, right-click the FLA file and selectMake default document from the context menu. (Sometimes this option won't appear thefirst time you select the file. If it doesn't, select the FLA file again.)
7. After the default document has been assigned, you can click the Test Project buttonto see the result of the program. Double-click any of the files to open them to makechanges.